package baseNoStates;

public final class State {
  public final static String LOCKED = "locked";
  public final static String UNLOCKED = "unlocked";
  public final static String UNLOCKED_SHORTLY = "unlocked_shortly";

}
